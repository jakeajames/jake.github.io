//
//  ViewController.swift
//  TTT
//
//  Created by jakea james on 8/23/16.
//  Copyright © 2016 jakea james. All rights reserved.
//

import UIKit


var score = 0;

class ViewController: UIViewController {

   
    @IBAction func c(_ sender: Any) {
        if(score >= 20) {
            score += 100;
    }
        else {
            
            let alert = UIAlertController(title: "Store", message: "You don't have enough clicks! Get 20 clicks first", preferredStyle: UIAlertControllerStyle.alert)
            
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        

        }
    }
    @IBAction func showscore(_ sender: Any) {
 
        let alert = UIAlertController(title: "Score", message: "Your score is: \(score)", preferredStyle: UIAlertControllerStyle.alert)
        
       
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        alert.addAction(UIAlertAction(title: "Reset", style: UIAlertActionStyle.cancel, handler: { action in
            score = 0;
        
        }))
        
        
       
        self.present(alert, animated: true, completion: nil)
            }
    @IBAction func clickme(_ sender: Any) {
        score += 1
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
   
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   }
