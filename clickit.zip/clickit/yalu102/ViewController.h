//
//  ViewController.h
//  yalu102
//
//  Created by qwertyoruiop on 05/01/2017.
//  Copyright © 2017 kimjongcracks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController
{
    IBOutlet UIButton* dope;

    IBOutlet UILabel *lbl;

    IBOutlet UIButton *dldo;
    
  

}
- (IBAction)yolo:(id)sender;
- (void)connectionDidFinishLoading:(NSURLConnection *)connection;

@end

